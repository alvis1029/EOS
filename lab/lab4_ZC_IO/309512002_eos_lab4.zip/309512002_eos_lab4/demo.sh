#!/bin/sh

set -x
# set -e

rmmod -f mydev
insmod mydev.ko

./writer ALVIS &
./reader 192.168.0.10 8888 /dev/mydev
