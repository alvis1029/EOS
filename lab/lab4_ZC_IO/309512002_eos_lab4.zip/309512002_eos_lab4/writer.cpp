#include <cstdio>       // fprintf(), perror()
#include <cstdlib>      // exit()
#include <cstring>      // memset()
#include <csignal>      // signal()
#include <fcntl.h>      // open()
#include <unistd.h>     // read(), write(), close()

#include <sys/socket.h> // socket(), connect()
#include <netinet/in.h> // struct sockaddr_in
#include <arpa/inet.h>  // htons()

int fd;

void sigint_handler(int sig) 
{
    close(fd);
}

int main(int argc, char *argv[]) 
{
    char my_name;

    if(argc != 2) 
    {
        fprintf(stderr, "Usage: ./writer <name>");
        exit(EXIT_FAILURE);
    }

    // Signal callback
    signal(SIGINT, sigint_handler);

    // Open driver
    if((fd = open("/dev/mydev", O_RDWR)) < 0) 
    {
        perror("/dev/mydev");
        exit(EXIT_FAILURE);
    }

    int ret, i = 0;

    for(i=0; i<5; i++) 
    {
        if(argv[1][i] == 'b' || argv[1][i] == 'd' || argv[1][i] == 'q')
            my_name = (argv[1][i] - 'a');
        else
            my_name = (argv[1][i] - 'A');

        printf("%d\n", my_name);

        if((ret = write(fd, &my_name, sizeof(my_name))) == -1)
        {
            perror("write()");
            exit(EXIT_FAILURE);
        }

        sleep(1);
    }

    close(fd);
    return 0;
}